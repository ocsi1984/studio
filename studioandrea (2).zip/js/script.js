
// Később ide jöhetnek animációk, például repkedő pillangók
console.log("Studio Andrea oldal betöltve!");
